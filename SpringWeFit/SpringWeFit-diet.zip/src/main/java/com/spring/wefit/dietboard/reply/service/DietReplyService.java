package com.spring.wefit.dietboard.reply.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.spring.wefit.command.DietBoardReplyVO;

@Service
public class DietReplyService implements IDietReplyService {

	@Override
	public void replyRegist(DietBoardReplyVO vo) {
		// TODO Auto-generated method stub

	}

	@Override
	public List<DietBoardReplyVO> getList(int bno) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public int getTotal(int bno) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int pwCheck(DietBoardReplyVO vo) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public void update(DietBoardReplyVO vo) {
		// TODO Auto-generated method stub

	}

	@Override
	public void delete(int rno) {
		// TODO Auto-generated method stub

	}

}
