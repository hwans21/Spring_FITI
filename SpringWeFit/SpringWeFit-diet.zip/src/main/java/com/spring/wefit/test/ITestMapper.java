package com.spring.wefit.test;


public interface ITestMapper {
	double test();
}
